TEMA 2 PCLP2

TASK 1:
    In cadrul acestui task, am implementat un program care sa verifice 
un cod de permisiuni, reperzentat cu 0 si 1. Am rezolvat aceasta cerinta
folosindu-ma de o masca, care lua valoarea 1 pe fiecare dintre cele 24 de 
pozitii ale codului, si insrtuctiunea 'test' (un si logic). Astfel, am 
verificat mai inatai daca bitul din cerere este 1 si daca da, am verificat si
bitul din codul de permisiuni. 

TASK 2:
Subtask1:
    Ordonarea request-urilor a fost facuta pe baza a 3 criterii. Implementarea
de fata are la baza:
- stocarea valorilor pe stiva pentru a elibera registrele pentru uz general
- analiza separata a campurilor structurii de request cu ajutorul offset-urilor
- interschimbarea a doua structuri a fost efectuata byte cu byte
- elementele au fost ordonare cu metoda interschimbarii (cu 2 loop-uri 'for')

! De mentionat ca ordonarea a fost facuta separat pentru fiecare criteriu, NU
simultan, pentru modularizarea implementarii.

Subtask2:
    Acest task presupune identificarea hacker-ilor dintr-un vector de cereri
cautand un anumit model al passkey-ului. Astfel, tinand cont de asezarea in
little endian a octetilor, am verificat criteriile de passkey ale unui hacker
folosind o masca si instructiuni de 'si logic' pentru:
- verificarea primului si ultimului bit (care trebuie sa fie setati pe 1)
- numararea bitilor din interiorul primului si ultimului octet
(se tine minte intr-un contor nr de biti setati pe 1)
    Daca un request apartine unui hacker, se seteaza pe 1 octetul din vectorul
de 'connections', altfel, octetul corespunzator ramane pe 0.

TASK 3:
    Acest task a preuspus implementarea unui program de criptare si decriptarii 
Treyfer a unui bloc text cu o dimensiune constanta, ce are la baza textul de 
criptat/decriptat (format din blocuri cu dimensiune egala), o cheie (un sir de 
caractere ce are lungimea unui bloc) si un 'sbox' (un sir de caractere care 
produce modificari in textul de criptat).

CRIPTARE:
- se aplica 10 runde de ciptare => se repeta de 10 ori loop-ul de criptare
- la fiecare runda, se aplica procedeul de ciptare pe fiecare octet din
bloc, porinind de la variabila t egala initial cu primul caracter din bloc
- operatiile pe blocul text se fac tot cu ajutorul offset-urilor si al stivei,
unde eliberam registrele de uz general
- criptarea se face 'in-place'

DECRIPTARE:
- se aplica tot 10 runde de criptare
- se efectueaza pasii de criptare in ordine inversa
- se porneste de la ultimul octet al blocului
- decriptarea se face 'in-place'

TASK 4:
    In acest task am realizat un program care gaseste iesirea dintr-un labirint,
urmarind drumul de 0-uri intr-o matrice de caractere de 1 si 0 (1 insemnand cale
blocata). Consideram labirintul ca avand o singura solutie si iesirea pe latura
stanga sau pe cea inferioara. Astfel, la fiecare inaintare intr-o noua celula:
- am verificat celuele de SUS, STANGA, JOS, DREAPTA (in aceasta ordine) daca 
exista; in caz contrar, treceam la verificarea urmatoarei celule din ordinea 
sus enuntata (spre exemplu, daca ne aflam pe linia 0, nu exista o celula in 
SUS)
- daca exista celula sus/stanga/jos/dreapta, verificam daca este marcata cu 0;
in caz afirmativ, ne mutam in acea celula (de unde vom efectua noua cautare)
si marcam celula precedenta pentru a nu parcurge drumul inapoi la urmatoarea
verificare
- daca am ajuns pe linia m-1 sau coloana n-1 => am iesit din labirint!
- indicii iesirii din labrirint sunt transmisi prin adresa in antetul functiei 
implementate